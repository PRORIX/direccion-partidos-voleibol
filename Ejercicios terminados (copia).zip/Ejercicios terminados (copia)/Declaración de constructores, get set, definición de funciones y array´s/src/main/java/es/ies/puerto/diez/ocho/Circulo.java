package es.ies.puerto.diez.ocho;
import java.util.Objects;

public class Circulo {

    private double radio;

    /**
     * Constructor vacío
     */

     public Circulo(){}

     /**
      * Constructor con parámetros
      * @param radio del círculo
      */

      public Circulo(double radio){
        this.radio = radio;
      }

      // Getters y setters


    public double getRadio() {
        return this.radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }

    /**
     * Método para calcular el área del círculo
     */

    public double area(){
        return Math.PI * Math.pow(this.radio, 2);
    }

    /**
     * Método para calcular el perímetro del círculo
     */

     public double perimetro(){
        return 2 * Math.PI * this.radio;
     }

     // Método para comparar círculos


    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Circulo)) {
            return false;
        }
        Circulo circulo = (Circulo) o;
        return radio == circulo.radio;
    }

    @Override
    public int hashCode() {
        return Double.hashCode(radio);
    }
     
}
