package es.ies.puerto.treinta.dos;
/**
 * Crea una clase Hospital que almacene una lista (array) (array)
 * de pacientes (clase Paciente). Implementa métodos para agregar, 
 * eliminar y listar pacientes. Usa toString() para describir el 
 * hospital.
 * @author prorix
 * @version 1.0.0
 */

public class Ejercicio32 {

    static Hospital hospital;
    public static void main(String[] args) {
        Paciente paciente1= new Paciente("Julián");
        hospital = new Hospital("La Laguna");
        hospital.aniadirPaciente(paciente1);
        System.out.println(hospital);
    }
    
}
