package es.ies.puerto.uno;

public class Uno {
    public static void main(String[] args) {
        Persona persona = new Persona("Juan Pérez", 28, "Masculino");
        System.out.println(persona); 
    }
}
