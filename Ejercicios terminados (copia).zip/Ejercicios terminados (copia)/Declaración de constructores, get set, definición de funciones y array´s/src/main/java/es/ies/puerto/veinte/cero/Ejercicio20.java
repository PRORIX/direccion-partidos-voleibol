package es.ies.puerto.veinte.cero;

public class Ejercicio20 {
    public static void main(String[] args) {
        Factura factura = new Factura("Leche", 5, 10.5f);
        System.out.println("Información de la factura: " + factura.toString());
        System.out.println("Precio total: " + factura.importeTotal());
    }
    
}
