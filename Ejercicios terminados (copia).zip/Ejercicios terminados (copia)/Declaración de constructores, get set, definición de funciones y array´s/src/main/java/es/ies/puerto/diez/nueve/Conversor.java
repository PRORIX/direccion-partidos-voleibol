package es.ies.puerto.diez.nueve;

public class Conversor {

    private double kilometros;

    /**
     * Constructor vacío
     */

     public Conversor(){}

     /**
      * Constructor con parámetros
      * @param kilometros a convertir
      */

      public Conversor(double kilometros){
        this.kilometros = kilometros;
      }

      // Getters y setters


    public double getKilometros() {
        return this.kilometros;
    }

    public void setKilometros(double kilometros) {
        this.kilometros = kilometros;
    }

    /**
     * Método para convertir kilómetros a millas
     */

    public double convertirAMillas(){
        return this.kilometros * 0.621371;
    }

    /**
     * Mostrar el resultado en pantalla
     */


    @Override
    public String toString() {
        return kilometros + " kilometros son " + convertirAMillas() + " millas.";
    }


    
}
