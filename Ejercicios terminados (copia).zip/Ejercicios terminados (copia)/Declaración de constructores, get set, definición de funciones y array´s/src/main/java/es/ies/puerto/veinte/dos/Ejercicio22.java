package es.ies.puerto.veinte.dos;

public class Ejercicio22 {
    public static void main(String[] args) {
        Articulo articulo = new Articulo("Mesa", 100, 2);
        Articulo articulo2 = new Articulo("Silla", 80, 3);

        System.out.println("Articulo 1: " + articulo.toString());
        System.out.println("Aumentado el stock del artículo 1: " + articulo.aumentarStock(2));
        System.out.println("Articulo 2: " + articulo2.toString());
        System.out.println("Disminuido el stock del artículo 2: " + articulo2.disminuirStock(1));
        System.out.println("¿El nombre de los artículos son iguales? " + articulo.equals(articulo2));
    }
    
}
