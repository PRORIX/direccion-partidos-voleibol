package es.ies.puerto.treinta.cero;
import java.util.Objects;

public class Cancion {

    private String titulo;

    // Constructor vacío

    public Cancion (){}
    
    /**
     * Constructor con parámetros
     * @param titulo de la canción
     */

    public Cancion (String titulo){
        this.titulo = titulo;
    }


    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Cancion)) {
            return false;
        }
        Cancion cancion = (Cancion) o;
        return Objects.equals(titulo, cancion.titulo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(titulo);
    }


    @Override
    public String toString() {
        return "{" +
            " titulo='" + titulo + "'" +
            "}";
    }

    
}
