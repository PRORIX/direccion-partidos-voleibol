package es.ies.puerto.diez.cuatro;

public class Ejercicio14 {
    public static void main(String[] args) {
        Coordenada coordenada = new Coordenada(1, 2);
        Coordenada coordenada2 = new Coordenada(2, 3);
        System.out.println("Punto 1: " + coordenada.toString());
        System.out.println("Punto 2: " + coordenada2.toString());
        System.out.println("Distancia entre ambos: " + coordenada.calcularDistancia());
    }
    
}
