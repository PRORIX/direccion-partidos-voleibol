package es.ies.puerto.diez.cero;

public class Ejercicio10 {
    public static void main(String[] args) {
        Pila pila = new Pila(10);

        pila.apilar(10);
        pila.apilar(20);
        
        System.out.println(pila);
    }
    
}
