package es.ies.puerto.diez.cinco;
/**
 * Crea una clase Poligono con un método area(). Implementa los 
 * métodos toString()y equals.
 * @author prorix
 * @version 1.0.0
 */
public class Poligono {
    private float lado;
    
}
