package es.ies.puerto.diez.cuatro;

public class Coordenada {
    private float x;
    private float y;

    /**
     * Constructor vacío
     */

     public Coordenada(){}
    /**
     * Constructor con parámetros
     * @param x coordenada x
     * @param y coordenada y
     */

     public Coordenada(float x, float y){
         this.x = x;
         this.y = y;
     }

     // Getters y setters


    public float getX() {
        return this.x;
    }

    public void setX(float x) {
        this.x = x;
    }

    public float getY() {
        return this.y;
    }

    public void setY(float y) {
        this.y = y;
    }

    /**
     * Método para calcular la distancia entre dos puntos
     */
    
    public float calcularDistancia(){
        return (float) Math.sqrt(Math.pow(this.x - 0, 2) + Math.pow(this.y - 0, 2));
    }


    @Override
    public String toString() {
        return "{" +
            " x='" + getX() + "'" +
            ", y='" + getY() + "'" +
            "}";
    }

}
