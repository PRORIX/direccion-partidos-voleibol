package es.ies.puerto.diez.seis;
import java.util.Objects;

/**
 * Crea una clase Fecha con atributos dia, mes y anio. 
 * Implementa métodos para validar si la fecha es correcta 
 * y para comparar dos fechas con equals().
 * @author prorix
 * @version 1.0.0
 */

public class Fecha {

    private int dia;
    private int mes;
    private int anio;

    /**
     * Constructor vacío
     */

     public Fecha (){}
     /**
      * Constructor con parámetros
      * @param dia de la fecha
      * @param mes de la fecha
      * @param anio de la fecha
      */

      public Fecha(int dia, int mes, int anio){
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
      }

      // Getters y setters


    public int getDia() {
        return this.dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return this.mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAnio() {
        return this.anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    // Método para comprobar si es bisiesto

    public boolean esBisiesto(){
        return (this.anio % 4 == 0 && this.anio % 100!= 0) || this.anio % 400 == 0;
    }

    // Método para comprobar si la fecha es válida

    public boolean esValida(){
        if (this.anio < 0) {
            return false;
        }
        if (this.mes < 1 || this.mes > 12) {
            return false;
        }
        int[] diasPorMes = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        if (this.mes == 2 && this.esBisiesto()) {
            diasPorMes[1] = 29;
        }
        return this.dia <= diasPorMes[this.mes - 1];
    }

    // Comparar dos fechas


    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Fecha)) {
            return false;
        }
        Fecha fecha = (Fecha) o;
        return dia == fecha.dia && mes == fecha.mes && anio == fecha.anio;
    }

    @Override
    public int hashCode() {
        return Objects.hash(dia, mes, anio);
    }
    

    
}
