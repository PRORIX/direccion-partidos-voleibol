package es.ies.puerto.diez.uno;

public class Vehiculo {

    private String marca;
    private String modelo;

/**
 * Constructor vacío
 */

 public Vehiculo(){}

 /**
 * Constructor con parámetros
 * @param marca del vehículo
 * @param modelo del vehículo
 */

 public Vehiculo(String marca, String modelo){
    this.marca = marca;
    this.modelo = modelo;
 }

 // Getters y setters


    public String getMarca() {
        return this.marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return this.modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }


    @Override
    public String toString() {
        return "{" +
            " marca='" + getMarca() + "'" +
            ", modelo='" + getModelo() + "'" +
            "}";
    }

}
