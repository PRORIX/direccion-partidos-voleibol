package es.ies.puerto.treinta.cero;

import es.ies.puerto.veinte.cuatro.Animal;
import es.ies.puerto.veinte.cuatro.Zoologico;

/**
 * Crea una clase Playlist que almacene una lista(array) de 
 * canciones (clase Cancion). Implementa métodos para agregar, 
 * eliminar y listar canciones. Usa toString() para mostrar la 
 * lista.
 * @author prorix
 * @version 1.0.0
 */
public class Ejercicio30 {
    static Playlist playlist;

        public static void main(String[] args) {

        Cancion cancion1= new Cancion("Devuélveme a mi chica");
        playlist = new Playlist("Musica dura");
        playlist.añadirCancion(cancion1);
        System.out.println(playlist);
        
    }
    
}
