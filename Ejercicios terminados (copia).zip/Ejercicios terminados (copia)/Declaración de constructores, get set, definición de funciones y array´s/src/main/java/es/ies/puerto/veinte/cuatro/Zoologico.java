package es.ies.puerto.veinte.cuatro;

public class Zoologico {

    private int numeroAnimales;
    private String nombre;
    private Animal[] animales;

    // Constructor vacío

    public Zoologico(){
        this.numeroAnimales = 0;
        animales = new Animal[5];
    }

    /**
     * Constructor con parámetros
     * @param nombre del zoo
     * @param animales que contiene el zoo
     */

    public Zoologico(String nombre){
        this.nombre = nombre;
        numeroAnimales = 0;
        animales = new Animal[5];
    }

    @Override
    public String toString() {
        String mensaje = "Nombre: " + nombre;
        for(Animal animal : animales){
            if(animal!=null){
                mensaje += "\n" + animal;
            }
        }
        return mensaje;
    }
/**
 * Función para añadir un animal en la lista
 * @param animal nuevo
 * @return true / false
 */
    public boolean añadirAnimal(Animal animal){
        
        if(animal == null){
            return false;
        }
        if (numeroAnimales >= animales.length){
            return false;
        }
        animales[numeroAnimales] = animal;
        numeroAnimales++;
        return true;
        
}

    public boolean quitarAnimal(Animal animalEliminar){
        if(animalEliminar == null){
            return false;
        }
        if(numeroAnimales == 0){
            return false;
        }
        for(int i = 0 ; i < animales.length ; i++){
            if(animales[i] != null){
                if(animalEliminar.equals(animales[i])){
                    animales[i] = null;
                    numeroAnimales--;
                    return true;
                }
            }
        }
        for (int i = 0; i < animales.length-1; i++) {
            if (animales[i] == null) {
                animales[i] = animales [i+1];
                animales[i+1] = null;
        }
    }
        return false;
    }
}
