package es.ies.puerto.veinte.cinco;
public class Concesionaria {

    private int numeroCoches;
    private String nombre;
    private Vehiculo[] vehiculos;

    // Constructor vacío

    public Concesionaria (){
        this.numeroCoches = 0;
        vehiculos = new Vehiculo[5];
    }

    /**
     * Constructor con parámetros
     * @param nombre del concesionario
     * @param vehiculos que tiene el concesionario
     */

    public Concesionaria(String nombre){
        this.nombre = nombre;
        numeroCoches = 0;
        vehiculos = new Vehiculo[5];
    }


    @Override
    public String toString() {
   String mensaje = "Nombre: " + nombre;
        for(Vehiculo vehiculo : vehiculos){
            if(vehiculo!=null){
                mensaje += "\n" + vehiculo;
            }
        }
        return mensaje;
    }

/**
 * Función para añadir un vehiculo en la lista
 * @param vehiculo nuevo
 * @return true / false
 */
public boolean añadirVehiculo(Vehiculo vehiculo){
        
    if(vehiculo == null){
        return false;
    }
    if (numeroCoches >= vehiculos.length){
        return false;
    }
    vehiculos[numeroCoches] = vehiculo;
    numeroCoches++;
    return true;
}

    
}
