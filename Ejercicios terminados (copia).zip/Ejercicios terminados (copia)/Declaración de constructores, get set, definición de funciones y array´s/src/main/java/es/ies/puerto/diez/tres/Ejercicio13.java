package es.ies.puerto.diez.tres;

public class Ejercicio13 {
    public static void main(String[] args) {
        Alumno alumno = new Alumno("Juan", 5, 6, 7);
        Alumno alumno2 = new Alumno("Pedro", 5, 2, 7);
        System.out.println(alumno.equals(alumno2));
    }
    
}
