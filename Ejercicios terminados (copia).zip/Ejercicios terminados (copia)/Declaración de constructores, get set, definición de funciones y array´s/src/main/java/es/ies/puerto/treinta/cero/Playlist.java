package es.ies.puerto.treinta.cero;

import es.ies.puerto.veinte.cuatro.Animal;

public class Playlist {

    private int numeroCanciones;
    private String nombre;
    private Cancion[] canciones;

    // Constructor vacío

    public Playlist () {
        this.numeroCanciones = 0;
        canciones = new Cancion[5];
    }

    /**
     * Constructor con parámetros
     * @param nombre de la playlist
     * @param canciones que contiene la playlist
     */

    public Playlist (String nombre){
        this.nombre = nombre;
        numeroCanciones = 0;
        canciones = new Cancion[5];
    }

        @Override
    public String toString() {
        String mensaje = "Nombre: " + nombre;
        for(Cancion cancion : canciones){
            if(cancion!=null){
                mensaje += "\n" + cancion;
            }
        }
        return mensaje;
    }

    /**
 * Función para añadir una cancion en la lista
 * @param cancion nueva
 * @return true / false
 */
public boolean añadirCancion(Cancion cancion){
        
    if(cancion == null){
        return false;
    }
    if (numeroCanciones >= canciones.length){
        return false;
    }
    canciones[numeroCanciones] = cancion;
    numeroCanciones++;
    return true;
}

/**
 * Función para quitar una canción de la lista
 * @param cancionEliminar
 * @return
 */
public boolean quitarCancion(Cancion cancionEliminar){
    if(cancionEliminar == null){
        return false;
    }
    if(numeroCanciones == 0){
        return false;
    }
    for(int i = 0 ; i < canciones.length ; i++){
        if(canciones[i] != null){
            if(cancionEliminar.equals(canciones[i])){
                canciones[i] = null;
                numeroCanciones--;
                return true;
            }
        }
    }
    for (int i = 0; i < canciones.length-1; i++) {
        if (canciones[i] == null) {
            canciones[i] = canciones [i+1];
            canciones[i+1] = null;
    }
}
    return false;
}


    
}
