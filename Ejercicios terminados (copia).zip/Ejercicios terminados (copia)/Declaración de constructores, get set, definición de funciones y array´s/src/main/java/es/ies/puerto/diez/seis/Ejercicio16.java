package es.ies.puerto.diez.seis;

public class Ejercicio16 {

    public static void main(String[] args) {
        Fecha fecha = new Fecha(29,2, 2025);
        Fecha fecha2 = new Fecha(1, 2, 2024);
        System.out.println("¿Son iguales? " + fecha.equals(fecha2));
        System.out.println("¿La fecha 1 es válida? " + fecha.esValida());
        System.out.println("¿La fecha 2 es válida? " + fecha2.esValida());
    }
    
}
