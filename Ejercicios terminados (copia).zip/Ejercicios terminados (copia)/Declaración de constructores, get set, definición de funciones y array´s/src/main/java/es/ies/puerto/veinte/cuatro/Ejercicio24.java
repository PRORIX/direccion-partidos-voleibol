package es.ies.puerto.veinte.cuatro;

public class Ejercicio24 {
    static Zoologico zoologico;
    public static void main(String[] args) {

        Animal animal1= new Animal("Julián", "León");
        zoologico = new Zoologico("Loro Parque");
        zoologico.añadirAnimal(animal1);
        System.out.println(zoologico);
        
    }
    
}
