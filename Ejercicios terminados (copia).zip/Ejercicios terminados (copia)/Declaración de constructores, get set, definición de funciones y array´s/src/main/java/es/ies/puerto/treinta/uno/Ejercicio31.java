package es.ies.puerto.treinta.uno;
/**
 * Crea una clase Pelicula con atributos titulo, director, y 
 * duracion. Implementa métodos para comparar películas 
 * por duración con equals() y usar toString() para mostrar 
 * detalles.
 * @author prorix
 * @version 1.0.0
 */
public class Ejercicio31 {

    public static void main(String[] args) {

        Pelicula pelicula1 = new Pelicula("The Shawshank Redemption", "Francis Ford Coppola", 142);
        Pelicula pelicula2 = new Pelicula("The Godfather", "Francis Ford Coppola", 175);
        System.out.println("Información de la pelicula 1: " + pelicula1);
        System.out.println("Información de la pelicula 2: " + pelicula2);
        System.out.println("Son iguales por duración: " + pelicula1.equals(pelicula2));
        
    }
    
}
