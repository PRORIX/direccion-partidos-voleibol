package es.ies.puerto.diez.dos;

public class Ejercicio12 {
    public static void main(String[] args) {
        Calculadora calculadora = new Calculadora(5, 3); 
        System.out.println(calculadora.toString());
        System.out.println("Suma de los numeros: " + calculadora.suma());
        System.out.println("Resta de los números: " + calculadora.resta());
        System.out.println("Multiplicación de los números: " + calculadora.multiplicacion());
        System.out.println("División de los números: " + calculadora.division());
    }
    
}
