package es.ies.puerto.siete;

public class Ejercicio7 {
    public static void main(String[] args) {
        Cuentabancaria cuentabancaria = new Cuentabancaria(600, "Romen", 123456);
        Cuentabancaria cuentabancaria2 = new Cuentabancaria(200, "Juan", 654321);
        System.out.println(cuentabancaria.equals(cuentabancaria2));
        System.out.println(cuentabancaria.toString());
        System.out.println(cuentabancaria2.toString());
        System.out.println(cuentabancaria.retirar());
        System.out.println(cuentabancaria2.retirar());
        System.out.println(cuentabancaria.depositar());
        System.out.println(cuentabancaria2.depositar());
    }
}
