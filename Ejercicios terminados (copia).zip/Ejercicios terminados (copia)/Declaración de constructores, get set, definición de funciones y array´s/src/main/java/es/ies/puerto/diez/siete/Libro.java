package es.ies.puerto.diez.siete;
import java.util.Objects;

public class Libro {

    private String titulo;
    private String autor;
    private int paginas;

    /**
     * Constructor por defecto
     */

     public Libro() {}
     /**
      * Constructor con parámetros
      * @param título del libro
      * @param autor del libro
      * @param número de páginas del libro
      */

      public Libro(String titulo, String autor, int paginas){
        this.titulo = titulo;
        this.autor = autor;
        this.paginas = paginas;
      }

      // Getters y setters


    public String getTitulo() {
        return this.titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return this.autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getPaginas() {
        return this.paginas;
    }

    public void setPaginas(int paginas) {
        this.paginas = paginas;
    }

    // Mostrar la información del libro


    @Override
    public String toString() {
        return "{" +
            " titulo='" + getTitulo() + "'" +
            ", autor='" + getAutor() + "'" +
            ", paginas='" + getPaginas() + "'" +
            "}";
    }

    // Comparar páginas


    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Libro)) {
            return false;
        }
        Libro libro = (Libro) o;
        return Objects.equals(paginas, libro.paginas);
    }

    @Override
    public int hashCode() {
        return Objects.hash(titulo, autor, paginas);
    }
    

}
