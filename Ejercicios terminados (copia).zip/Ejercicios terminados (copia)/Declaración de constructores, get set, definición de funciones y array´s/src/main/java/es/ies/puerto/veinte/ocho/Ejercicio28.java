package es.ies.puerto.veinte.ocho;

public class Ejercicio28 {
    public static void main(String[] args) {
        Ciudad ciudad = new Ciudad("Hogwarts", "Estados Unidos", 10000);
        Ciudad ciudad2 = new Ciudad("Narnia", "Holanda", 10);
        System.out.println("Ciudad 1: " + ciudad);
        System.out.println("Ciudad 2: " + ciudad2);
        System.out.println("Tienen igual población: " + ciudad.equals(ciudad2));
    }
}
