package es.ies.puerto.veinte.cero;

public class Factura {

    private String producto;
    private int cantidad;
    private float precio;
    
    /**
     * Constructor vacío
     */

     public Factura(){}
     /**
      * Constructor con parámetros
      * @param producto del producto
      * @param cantidad de unidades
      * @param precio del producto
      */

      public Factura(String producto, int cantidad, float precio){
        this.producto = producto;
        this.cantidad = cantidad;
        this.precio = precio;
      }

      // Getters y setters


    public String getProducto() {
        return this.producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public int getCantidad() {
        return this.cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public float getPrecio() {
        return this.precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    /**
     * Método para calcular el importe total de la factura
     */

    public float importeTotal(){
        return this.cantidad * this.precio;
    }

    /**
     * Mostrar la información de la factura
     */


    @Override
    public String toString() {
        return "{" +
            " producto='" + getProducto() + "'" +
            ", cantidad='" + getCantidad() + "'" +
            ", precio='" + getPrecio() + "'" +
            "}";
    }


}
