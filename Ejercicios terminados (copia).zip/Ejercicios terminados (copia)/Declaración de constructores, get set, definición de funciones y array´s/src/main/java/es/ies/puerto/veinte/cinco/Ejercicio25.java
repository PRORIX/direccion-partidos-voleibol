package es.ies.puerto.veinte.cinco;

/**
 * Crea una clase Concesionaria con una lista (array) (array) 
 * de vehículos (clase Vehiculo). Implementa métodos para 
 * agregar vehículos, listar todos los vehículos y usar 
 * toString() para mostrar detalles.
 * @author prorix
 * @version 1.0.0
 */

public class Ejercicio25 {
    public static void main(String[] args) {
        Vehiculo vehiculo1 = new Vehiculo("Toyota", "Corolla");
        Vehiculo vehiculo2 = new Vehiculo("Ford", "Mustang");
        Concesionaria concesionaria = new Concesionaria("Los coches del mundo");
        concesionaria.añadirVehiculo(vehiculo1);
        concesionaria.añadirVehiculo(vehiculo2);
        System.out.println(concesionaria);
    }
    
}
