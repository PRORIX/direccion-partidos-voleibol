package es.ies.puerto.seis;

public class Ejercicio6 {
    public static void main(String[] args) {
        Estudiante estudiante = new Estudiante("Juan", "123456", 10);
        System.out.println(estudiante.toString());
    }
}
