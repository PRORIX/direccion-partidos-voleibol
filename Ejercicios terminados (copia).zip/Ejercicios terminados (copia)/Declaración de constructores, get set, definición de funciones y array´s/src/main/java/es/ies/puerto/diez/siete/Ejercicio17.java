package es.ies.puerto.diez.siete;

public class Ejercicio17 {

    public static void main(String[] args) {
        Libro libro = new Libro("El Quijote", "Miguel de Cervantes", 1216);
        Libro libro2 = new Libro("Las maravillas de Johatam", "Johatam", 126);
        System.out.println("Datos del libro 1: " + libro.toString());
        System.out.println("Datos del libro 2: " + libro2.toString());
        System.out.println("¿Tienen las mismas páginas? " + libro.equals(libro2));
    }
    
}
