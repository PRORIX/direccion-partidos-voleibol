package es.ies.puerto.treinta.siete;

public class Partido {

    private String equipoLocal;
    private String equipoVisitante;
    private int golesLocal;
    private int golesVisitante;
    /**
     * Constructor por defecto
     */

    public Partido() {}

    /**
     * Constructor conn parámetros
     * @param equipoLocal del partido
     * @param equipoVisitante del partido
     * @param golesLocal del partido
     * @param golesVisitante del partido
     */

    public Partido (String equipoLocal, String equipoVisitante, int golesLocal, int golesVisitante){
        this.equipoLocal = equipoLocal;
        this.equipoVisitante = equipoVisitante;
        this.golesLocal = golesLocal;
        this.golesVisitante = golesVisitante;
    }

    // Getters y setters


    public String getEquipoLocal() {
        return this.equipoLocal;
    }

    public void setEquipoLocal(String equipoLocal) {
        this.equipoLocal = equipoLocal;
    }

    public String getEquipoVisitante() {
        return this.equipoVisitante;
    }

    public void setEquipoVisitante(String equipoVisitante) {
        this.equipoVisitante = equipoVisitante;
    }

    public int getGolesLocal() {
        return this.golesLocal;
    }

    public void setGolesLocal(int golesLocal) {
        this.golesLocal = golesLocal;
    }

    public int getGolesVisitante() {
        return this.golesVisitante;
    }

    public void setGolesVisitante(int golesVisitante) {
        this.golesVisitante = golesVisitante;
    }

    // Mostrar detalles del partido


    @Override
    public String toString() {
        String resultado = golesLocal + " - " + golesVisitante;
        return "{" +
            " equipo local='" + getEquipoLocal() + "'" +
            ", equipo visitante='" + getEquipoVisitante() + "'" +
            ", resultado del partido='" + resultado + "'" +
            "}";
    }


    
}
