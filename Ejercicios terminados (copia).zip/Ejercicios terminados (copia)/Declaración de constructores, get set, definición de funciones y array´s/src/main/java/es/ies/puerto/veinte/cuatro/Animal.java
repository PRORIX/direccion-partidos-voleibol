package es.ies.puerto.veinte.cuatro;
import java.util.Objects;

public class Animal {

    private String nombre;
    private String especie;

    // Constructor vacío

    public Animal(){}

    /**
     * Constructor con parámetros
     * @param nombre del animal
     * @param especia del animal
     */

    public Animal(String nombre, String especie){
        this.nombre = nombre;
        this.especie = especie;
    }

    // Getters y setters


    @Override
    public boolean equals(Object o) {
        
        if (o == this)
            return true;
        if (!(o instanceof Animal)) {
            return false;
        }
        Animal animal = (Animal) o;
        return Objects.equals(nombre, animal.nombre) && Objects.equals(especie, animal.especie);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, especie);
    }


    @Override
    public String toString() {
        return "{" +
            " nombre='" + nombre + "'" +
            ", especie='" + especie + "'" +
            "}";
    }



    
    
}
