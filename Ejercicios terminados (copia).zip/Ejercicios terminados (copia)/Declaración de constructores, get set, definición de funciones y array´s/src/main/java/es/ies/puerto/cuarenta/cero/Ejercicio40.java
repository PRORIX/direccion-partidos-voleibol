package es.ies.puerto.cuarenta.cero;

public class Ejercicio40 {

    public static void main(String[] args) {
        Ebook ebook1 = new Ebook("Siso", 1000, 2024);
        Ebook ebook2 = new Ebook("Suso", 2000, 1009);
        BibliotecaDijital biblioteca = new BibliotecaDijital("Los libros de ROMEN");
        biblioteca.aniadirEbook(ebook1);
        biblioteca.aniadirEbook(ebook2);
        System.out.println(biblioteca);
        biblioteca.eliminarEbook(ebook2);
        System.out.println(biblioteca);
    }
    
}
