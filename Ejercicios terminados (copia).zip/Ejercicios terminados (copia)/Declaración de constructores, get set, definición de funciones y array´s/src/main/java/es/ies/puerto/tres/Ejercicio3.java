package es.ies.puerto.tres;

public class Ejercicio3 {
    public static void main(String[] args) {
        Rectangulo rectangulo1 = new Rectangulo(5, 10);
        Rectangulo rectangulo2 = new Rectangulo(1, 12);
        System.out.println(rectangulo1.toString());
        System.out.println(rectangulo2.toString());
        System.out.println(rectangulo1.equals(rectangulo2));
    }
}
