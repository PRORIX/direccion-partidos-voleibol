package es.ies.puerto.veinte.siete;

public class Ejercicio27 {
    public static void main(String[] args) {
        Planeta planeta = new Planeta("Tierra", 5.97*10e24 , 6380000);
        System.out.println("Información del planeta: " + planeta.toString());
        System.out.println("Gravedad en superficie: " + planeta.gravedadSuperficie());
    }
    
}
