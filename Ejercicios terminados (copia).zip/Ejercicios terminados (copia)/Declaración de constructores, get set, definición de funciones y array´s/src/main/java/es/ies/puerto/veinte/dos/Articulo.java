package es.ies.puerto.veinte.dos;

import java.util.Objects;

/**
 * Crea una clase Articulo con atributos nombre, precio, y stock. 
 * Implementa métodos aumentarStock() y disminuirStock(). 
 * Usa equals() para comparar artículos por su nombre y toString() 
 * para mostrar su información.
 * @author prorix
 * @version 1.0.0
 */

public class Articulo {

    private String nombre;
    private float precio;
    private int stock;

    /**
     * Constructor vacío
     */

     public Articulo() {}

     /**
      * Constructor con parámetros
      * @param nombre del artículo
      * @param precio del artículo
      * @param stock del artículo
      */

      public Articulo(String nombre, float precio, int stock){
        this.nombre = nombre;
        this.precio = precio;
        this.stock = stock;
      }

      // Getters y setters


    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getPrecio() {
        return this.precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public int getStock() {
        return this.stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    // Métodos para aumentar y disminuir stock

    public int aumentarStock(int cantidad){
        if(cantidad > 0){
        return stock += cantidad;
        }else{
            return stock = stock;
        }
    }

    public int disminuirStock(int cantidad){
        if(cantidad > 0){
        return stock -= cantidad;
        }else{
            return stock = stock;
        }
    }

    // Comparar artículos por su nombre


    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Articulo)) {
            return false;
        }
        Articulo articulo = (Articulo) o;
        return Objects.equals(nombre, articulo.nombre);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre);
    }

    // Mostrar información del artículo


    @Override
    public String toString() {
        return "{" +
            " nombre='" + getNombre() + "'" +
            ", precio='" + getPrecio() + "'" +
            ", stock='" + getStock() + "'" +
            "}";
    }







    
}
