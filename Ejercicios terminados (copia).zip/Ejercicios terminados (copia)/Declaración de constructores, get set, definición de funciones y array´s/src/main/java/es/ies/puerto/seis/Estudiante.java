package es.ies.puerto.seis;

public class Estudiante {
    private String nombre;
    private String matricula;
    private int clasificacion;

    /**
     * Constructor por defecto
     */
    public Estudiante() {}
    
    /**
     * constructor general
     * @param nombre del estudiante
     * @param matricula del estudiante
     * @param clasificacion del estudiante
     */

     public Estudiante(String nombre, String matricula, int clasificacion) {
        this.nombre = nombre;
        this.matricula = matricula;
        this.clasificacion = clasificacion;
    }

    // Getters y setters


    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMatricula() {
        return this.matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public int getClasificacion() {
        return this.clasificacion;
    }

    public void setClasificacion(int clasificacion) {
        this.clasificacion = clasificacion;
    }


    @Override
    public String toString() {
        return "{" +
            " nombre='" + getNombre() + "'" +
            ", matricula='" + getMatricula() + "'" +
            ", clasificacion='" + getClasificacion() + "'" +
            "}";
    }

}
