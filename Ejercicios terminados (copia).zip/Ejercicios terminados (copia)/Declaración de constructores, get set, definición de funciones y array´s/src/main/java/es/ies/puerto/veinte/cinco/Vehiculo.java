package es.ies.puerto.veinte.cinco;
import java.util.Objects;

public class Vehiculo {
    private String marca;
    private String modelo;

    // Constructor vacío

    public Vehiculo (){}

    /**
     * Constructor con parámetros
     * @param marca del vehiculo
     * @param modelo del vehiculo
     */

     public Vehiculo(String marca, String modelo){
        this.marca = marca;
        this.modelo = modelo;
    }

    // Getters y setters


    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Vehiculo)) {
            return false;
        }
        Vehiculo vehiculo = (Vehiculo) o;
        return Objects.equals(marca, vehiculo.marca) && Objects.equals(modelo, vehiculo.modelo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(marca, modelo);
    }


    @Override
    public String toString() {
        return "{" +
            " marca='" + marca + "'" +
            ", modelo='" + modelo + "'" +
            "}";
    }

    
    
}
