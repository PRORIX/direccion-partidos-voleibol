package es.ies.puerto.diez.nueve;

public class Ejercicio19 {
    public static void main(String[] args) {
        Conversor conversor = new Conversor(100);
        System.out.println(conversor.toString());
    }
    
}
