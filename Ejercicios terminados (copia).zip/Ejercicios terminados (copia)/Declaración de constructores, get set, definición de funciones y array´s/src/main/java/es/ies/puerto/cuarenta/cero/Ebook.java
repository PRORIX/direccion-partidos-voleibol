package es.ies.puerto.cuarenta.cero;

public class Ebook {

    private String nombre;
    private int isbn;
    private int anio;

    // Constructor por defecto

    public Ebook(){}

    /**
     * Constructor con parámetros
     * @param nombre del libro
     * @param isbn del libro
     * @param anio del libro
     */
    
    public Ebook(String nombre, int isbn, int anio) {
        this.nombre = nombre;
        this.isbn = isbn;
        this.anio = anio;
    }

    // Getters y setters


    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getIsbn() {
        return this.isbn;
    }

    public void setIsbn(int isbn) {
        this.isbn = isbn;
    }

    public int getAnio() {
        return this.anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }


    @Override
    public String toString() {
        return "{" +
            " nombre='" + getNombre() + "'" +
            ", isbn='" + getIsbn() + "'" +
            ", anio='" + getAnio() + "'" +
            "}";
    }


}
