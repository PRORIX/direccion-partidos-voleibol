package es.ies.puerto.cuarenta.cero;

public class BibliotecaDijital {

    private int numeroLibros;
    private String nombre;
    private Ebook[] ebooks;

    // Constructor vacío

    public BibliotecaDijital(){
    }

    /**
     * Constructor con parámetros
     * @param nombre de la biblioteca
     * @param libros de la biblioteca
     */

     public BibliotecaDijital(String nombre){
        this.nombre = nombre;
        ebooks = new Ebook[5];
     }


    @Override
    public String toString() {
        String mensaje = "Nombre: " + nombre;
        for(Ebook ebook : ebooks){
            if(ebook!=null){
                mensaje += "\n" + ebook;
            }
        }
        return mensaje;
    }

    // Método para añadir libros a la lista

    public boolean aniadirEbook(Ebook ebook){
        if(ebook == null){
            return false;
        }
        if (numeroLibros >= ebooks.length){
            return false;
        }
        ebooks[numeroLibros] = ebook;
        numeroLibros++;
        return true;
    }

    // Método para eliminar libros de la lista

    public boolean eliminarEbook(Ebook ebook){
        if(ebook == null){
            return false;
        }
        for(int i=0; i<numeroLibros; i++){
            if(ebooks[i] == ebook){
                ebooks[i] = null;
                numeroLibros--;
                for(int j=i; j<numeroLibros; j++){
                    ebooks[j] = ebooks[j+1];
                }
                return true;
            }
        }
        return false;
    }

    // Método para cambiar un libro

    
}
