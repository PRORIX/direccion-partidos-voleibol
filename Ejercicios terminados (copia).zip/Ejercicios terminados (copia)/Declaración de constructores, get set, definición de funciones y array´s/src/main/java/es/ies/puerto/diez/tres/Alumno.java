package es.ies.puerto.diez.tres;
import java.util.Objects;

public class Alumno {

    private String nombre;
    private float notaMatematicas;
    private float notaCiencias;
    private float notaProgramacion;

    /**
     * Constructor vacío
     */

     public Alumno (){}
     /**
      * constructor con parámnetros
      @param nombre del alumno
      @param notaMatematicas del alumno
      @param notaCiencias del alumno
      @param notaProgramacion del alumno
      */

      public Alumno (String nombre, float notaMatematicas, float notaCiencias, float notaProgramacion){
        this.nombre = nombre;
        this.notaMatematicas = notaMatematicas;
        this.notaCiencias = notaCiencias;
        this.notaProgramacion = notaProgramacion;
      }

      // Getters y setters


    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getNotaMatematicas() {
        return this.notaMatematicas;
    }

    public void setNotaMatematicas(float notaMatematicas) {
        this.notaMatematicas = notaMatematicas;
    }

    public float getNotaCiencias() {
        return this.notaCiencias;
    }

    public void setNotaCiencias(float notaCiencias) {
        this.notaCiencias = notaCiencias;
    }

    public float getNotaProgramacion() {
        return this.notaProgramacion;
    }

    public void setNotaProgramacion(float notaProgramacion) {
        this.notaProgramacion = notaProgramacion;
    }

    /**
     * Método para calcular el promedio de las notas
     */

     public double promedio(){
        return (this.notaMatematicas + this.notaCiencias + this.notaProgramacion) / 3;
     }

     /**
      * Método para comparar alumnos
      */


    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Alumno)) {
            return false;
        }
        Alumno alumno = (Alumno) o;
        return Objects.equals (notaMatematicas, alumno.notaMatematicas) && notaCiencias == alumno.notaCiencias && notaProgramacion == alumno.notaProgramacion;
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, notaMatematicas, notaCiencias, notaProgramacion);
    }
      

    
}
