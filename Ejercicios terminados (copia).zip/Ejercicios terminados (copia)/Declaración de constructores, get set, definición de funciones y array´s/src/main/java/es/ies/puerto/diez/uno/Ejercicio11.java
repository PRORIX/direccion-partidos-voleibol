package es.ies.puerto.diez.uno;

public class Ejercicio11 {

    public static void main(String[] args) {
        Vehiculo vehiculo = new Vehiculo("Toyota", "Corolla");
        System.out.println(vehiculo.toString());
    }
    
}
