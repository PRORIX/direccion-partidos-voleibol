package es.ies.puerto.veinte.siete;

/**
 * Define una clase Planeta con atributos nombre, masa, y radio. 
 * Implementa métodos para calcular la gravedad en la superficie 
 * del planeta. Usa toString() para describir el planeta.
 * @author prorix
 * @version 1.0.0
 */

public class Planeta {

    private String nombre;
    private double masa;
    private double radio;

    // Constructor vacío

    public Planeta() {}

    /**
     * Constructor con parámetros
     * @param nombre del planeta
     * @param masa del planeta
     * @param radio del planeta
     */

    public Planeta(String nombre, double masa, double radio){
        this.nombre = nombre;
        this.masa = masa;
        this.radio = radio;
    }

    // Getters y setters


    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getMasa() {
        return this.masa;
    }

    public void setMasa(double masa) {
        this.masa = masa;
    }

    public double getRadio() {
        return this.radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }

    // Método para calcular la gravedad en la superficie del planeta

    public double gravedadSuperficie(){
        return (this.masa) / (Math.pow(this.radio, 2));
    }

    // Método para describir el planeta


    @Override
    public String toString() {
        return "{" +
            " nombre='" + getNombre() + "'" +
            ", masa='" + getMasa() + "'" +
            ", radio='" + getRadio() + "'" +
            "}";
    }

    
}
