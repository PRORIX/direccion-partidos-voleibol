package es.ies.puerto.veinte.ocho;
import java.util.Objects;

/**
 * Crea una clase Ciudad con atributos nombre, pais, y poblacion. 
 * Implementa métodos para comparar ciudades por su población 
 * con equals() y usar toString() para describir la ciudad.
 * @author prorix
 * @version 1.0.0
 */

public class Ciudad {

    private String nombre;
    private String pais;
    private int poblacion;

    // Constructor por defecto

    public Ciudad(){}

    /**
     * Constructor con parámetros
     * @param nombre de la ciudad
     * @param pais de la ciudad
     * @param poblacion de la ciudad
     */
    
     public Ciudad(String nombre, String pais, int poblacion){
        this.nombre = nombre;
        this.pais = pais;
        this.poblacion = poblacion;
      }

    // Getters y setters


    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPais() {
        return this.pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public int getPoblacion() {
        return this.poblacion;
    }

    public void setPoblacion(int poblacion) {
        this.poblacion = poblacion;
    }

    // Método para comparar ciudades por su población


    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Ciudad)) {
            return false;
        }
        Ciudad ciudad = (Ciudad) o;
        return Objects.equals(poblacion,ciudad.poblacion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, pais, poblacion);
    }

    // Método para describir la ciudad


    @Override
    public String toString() {
        return "{" +
            " nombre='" + getNombre() + "'" +
            ", pais='" + getPais() + "'" +
            ", poblacion='" + getPoblacion() + "'" +
            "}";
    }

    
    
}
