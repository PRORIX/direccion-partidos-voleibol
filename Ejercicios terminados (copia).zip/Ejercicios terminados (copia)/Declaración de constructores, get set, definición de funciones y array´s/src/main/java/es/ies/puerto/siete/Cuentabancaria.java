package es.ies.puerto.siete;
import java.util.Objects;

public class Cuentabancaria {

    private double saldo;
    private String titular;
    private int numero;

    /**
     * Constructor por defecto
     */

     public Cuentabancaria() {}

     /**
      * Constructor con parámetros
      @param saldo de la cuenta
      @param titular de la cuenta
      @param numero de la cuenta
      */

      public Cuentabancaria(double saldo, String titular, int numero) {
        this.saldo = saldo;
        this.titular = titular;
        this.numero = numero;
    }

    // Getters y setters


    public double getSaldo() {
        return this.saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String getTitular() {
        return this.titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public int getNumero() {
        return this.numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public double depositar(){
        return this.saldo = saldo + 10;
    }
    
    double cantidad = 500;

    public double retirar(){
        if (saldo < cantidad){
            System.out.println("Saldo insuficiente. No se realiza el retiro.");
        } else if (saldo > cantidad){
            saldo -= cantidad;
        } else {
            System.out.println("a");
        }
        return saldo;
    }


    @Override
    public String toString() {
        return "{" +
            " saldo='" + getSaldo() + "'" +
            ", titular='" + getTitular() + "'" +
            ", numero='" + getNumero() + "'" +
            "}";
    }


    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Cuentabancaria)) {
            return false;
        }
        Cuentabancaria cuentabancaria = (Cuentabancaria) o;
        return numero == cuentabancaria.numero;
    }

    @Override
    public int hashCode() {
        return Objects.hash(saldo, titular, numero);
    }



    
}
