package es.ies.puerto.treinta.dos;
public class Hospital {

    private int numeroPacientes;
    private String nombre;
    private Paciente[] pacientes;

    // Constructor vacío

    public Hospital () {
        this.numeroPacientes = 0;
        pacientes = new Paciente[5];
    }

    /**
     * Constructor con parámetros
     * @param nombre del hospital
     * @param pacientes que contiene el hospital
     */

    public Hospital (String nombre){
        this.nombre = nombre;
        numeroPacientes = 0;
        pacientes = new Paciente[5];
    }

        @Override
    public String toString() {
        String mensaje = "Nombre: " + nombre;
        for(Paciente paciente : pacientes){
            if(paciente!=null){
                mensaje += "\n" + paciente;
            }
        }
        return mensaje;
    }

    /**
 * Función para añadir una paciente en el hospital
 * @param paciente nuevo
 * @return true / false
 */
public boolean aniadirPaciente(Paciente paciente){
        
    if(paciente == null){
        return false;
    }
    if (numeroPacientes >= pacientes.length){
        return false;
    }
    pacientes[numeroPacientes] = paciente;
    numeroPacientes++;
    return true;
}
}

