package es.ies.puerto.treinta.dos;
import java.util.Objects;

public class Paciente {

    private String nombre;

    // Constructor vacío

    public Paciente(){}

    /**
     * Constructor con parámetros
     * @param nombre del paciente
     */

     public Paciente(String nombre){
        this.nombre = nombre;
    }


    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Paciente)) {
            return false;
        }
        Paciente paciente = (Paciente) o;
        return Objects.equals(nombre, paciente.nombre);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre);
    }


    @Override
    public String toString() {
        return "{" +
            " nombre='" + nombre + "'" +
            "}";
    }


    
}
