package es.ies.puerto.diez.dos;

public class Calculadora {

    private static float numero;
    private static float numero2;

/**
 * constructor vacío
 */

 public Calculadora(){}

 /**
 * constructor con parámetros
 * @param numero número que se usará en las operaciones
 * @param numero2 número que se usará en las operaciones
 */

 public Calculadora(float numero, float numero2){
this.numero = numero;
this.numero2 = numero2;
 }
 

 // Getters y setters


    public float getNumero(){
        return this.numero;
    }

    public void setNumero(float numero) {
        this.numero = numero;
    }

    public float getNumero2() {
        return this.numero2;
    }

    public void setNumero2(float numero2) {
        this.numero2 = numero2;
    }

    static float suma(){
        return numero + numero2;
    }
    static float resta(){
        return numero - numero2;
    }
    static float multiplicacion(){
        return numero * numero2;
    }
    static float division(){
        if(numero2!=0){
            return numero / numero2;
            }else {
            System.out.println("Error: División por cero.");
            return 0;
            }
    
        

        }
    

    @Override
    public String toString() {
        return "Numero 1: " + numero + "\nNumero2: " + numero2;
    }
    
    }

