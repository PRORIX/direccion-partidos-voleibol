package es.ies.puerto.veinte.seis;
import java.util.Objects;

public class Libro {

    private String titulo;

    // Constructor vacío

    public Libro (){}

    /**
     * Constructor con parámetros
     * @param titulo del libro
     */

    public Libro (String titulo){
        this.titulo = titulo;
    }
    

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Libro)) {
            return false;
        }
        Libro libro = (Libro) o;
        return Objects.equals(titulo, libro.titulo);
    }


    @Override
    public String toString() {
        return "{" +
            " titulo='" + titulo + "'" +
            "}";
    }

    


}
