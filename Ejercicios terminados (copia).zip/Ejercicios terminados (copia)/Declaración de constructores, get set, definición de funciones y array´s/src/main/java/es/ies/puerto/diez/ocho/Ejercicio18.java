package es.ies.puerto.diez.ocho;

public class Ejercicio18 {
    public static void main(String[] args) {
        Circulo circulo = new Circulo(10);
        Circulo circulo2 = new Circulo(10);
        System.out.println("CIRCULO 1: Área: " + circulo.area() + ", Perímetro: " + circulo.perimetro());
        System.out.println("CIRCULO 2: Área: " + circulo2.area() + ", Perímetro: " + circulo2.perimetro());
        System.out.println("¿Son iguales? " + circulo.equals(circulo2));
    }
    
}
