package es.ies.puerto.tres;

import es.ies.puerto.dos.Producto;
import java.util.Objects;

public class Rectangulo {
    private double ancho;
    private double alto;

/**
 * Constructor por defecto
 */
 public Rectangulo(){}


 /**
 * Constructor general
 * @param ancho del rectángulo
 * @param alto del rectángulo
 */

 public Rectangulo(double ancho, double alto){
    this.ancho = ancho;
    this.alto = alto;
 }

    public double getAncho() {
        return this.ancho;
    }

    public void setAncho(double ancho) {
        this.ancho = ancho;
    }

    public double getAlto() {
        return this.alto;
    }

    public void setAlto(double alto) {
        this.alto = alto;
    }

    public double carea() {
        return ancho * alto;
    }

    public double perimetro() {
        return 2 * (ancho + alto);
    }
/**
 * Muestra la información del rectángulo
 */
 @Override
 public String toString(){
    return "Información del rectángulo: \n"
    + "Ancho: " + ancho + "\n"
    + "Alto: " + alto + "\n"
    + "Área: " + carea() + "\n"
    + "Perímetro: " + perimetro();
 }

 /**
  * compara los rectángulos
  */

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Rectangulo)) {
            return false;
        }
        Rectangulo rectangulo = (Rectangulo) o;
        return ancho == rectangulo.ancho && alto == rectangulo.alto;
    }

    @Override
    public int hashCode() {
        return Objects.hash(ancho, alto);
    }

}