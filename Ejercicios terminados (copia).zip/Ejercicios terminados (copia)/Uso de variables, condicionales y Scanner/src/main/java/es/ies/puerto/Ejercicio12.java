package es.ies.puerto;
import java.util.Scanner;
/**
 * Batman y Superman están peleando. Si la fuerza de 
 * Superman es mayor a la de Batman, Superman gana. 
 * Si es menor, Batman gana. Si tienen la misma fuerza, 
 * es un empate.
 * 
 * @author PRORIX
 * Version: 1.0.0.240924
 */
public class Ejercicio12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
       System.out.println("SUPERMAN: ¿Pero mira quién está aquí? ¡Un flojo!");
       System.out.println("BATMAN: Yo... Soy Batman...");
       System.out.println("SUPERMAN: Y tu... Hoy morirás.");
       
       System.out.print("\nElije el poder de Superman: ");
       int poderSuperman = scanner.nextInt();
       System.out.print("\nElije el poder de Batman: ");
       int poderBatman = scanner.nextInt();

        if (poderSuperman > poderBatman){
            System.out.println("\n(Gana Superman)");
            System.out.println("SUPERMAN: ¿Viste? Lo que dije, ¡Un flojo!");
        }else if (poderSuperman < poderBatman){
            System.out.println("\n(Gana Batman)");
            System.out.println("BATMAN: ¿Quién es el flojo ahora?");
        }else{
            System.out.println("\n(Empate)");
            System.out.println("SUPERMAN: He tenido suficiente, volveremos a encontrarnos...");
            System.out.println("BATMAN: Eso, uye...");
        }
        scanner.close();
            }
        }  
