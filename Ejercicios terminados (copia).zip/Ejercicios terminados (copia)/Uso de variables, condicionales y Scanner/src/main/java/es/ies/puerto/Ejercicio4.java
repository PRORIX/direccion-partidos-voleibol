package es.ies.puerto;
import java.util.Scanner;

/**
 * Si eres un Sith o un Jedi, puedes usar la Fuerza. 
 * Si no, eres un simple mortal.
 * 
 * @author PRORIX
 * Version: 1.0.0.240924
 */

public class Ejercicio4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
    
        System.out.println("GUARDIA: ¡Prohibido el paso! Aquí solo pueden acceder quienes tengan la capacidad de usar la fuerza.");
        System.out.println("\nJUEGO: ¿Qué eres?\n");
        System.out.println("A. Un Sith.");
        System.out.println("B. Un Jedi.");
        System.out.println("C. Un mortal.");
        System.out.print("\nOPCION ELEGIDA: ");

        String opcion = scanner.nextLine();

        if ("A".equals(opcion)) {
        System.out.println("\nTÚ: Soy un Sith, ¡Abre paso!");
        System.out.println("GUARDIA: Está bien, adelante.");
        }else if ("B".equals(opcion)){
        System.out.println("\nTÚ: Soy un Jedi, ¡Abre paso!");
        System.out.println("GUARDIA: Está bien, adelante.");
        }else if ("C".equals(opcion)){
        System.out.println("\nTÚ: Soy un humano, ¡déjame pasar!");
        System.out.println("GUARDIA: ¡Jamás!");
        }else{
        System.out.println("\nJUEGO: Parece que no has elegido una opción valida, inténtalo de nuevo.");
        }
        scanner.close();
    }
}