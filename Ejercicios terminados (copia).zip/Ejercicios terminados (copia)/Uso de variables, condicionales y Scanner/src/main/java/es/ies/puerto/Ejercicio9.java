package es.ies.puerto;
import java.util.Scanner;
/**
 * Para hacer la fusión, los guerreros deben tener la 
 * misma cantidad de ki. Si los valores de ki no 
 * coinciden, la fusión falla.
 * 
 * @author PRORIX
 * Version: 1.0.0.240924
 */

public class Ejercicio9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("VEGETA: ¡Rápido! ¡Tenemos que fusionarnos o moriremos!");
        System.out.println("\nGOKU: Está bien, ¡Vamos allá!\n");
        System.out.print("JUEGO: Establece el niver de Ki de Vegeta: ");
        int poderVegeta = scanner.nextInt();
        System.out.print("JUEGO: Establece el niver de Ki de Goku: ");
        int poderGoku = scanner.nextInt();
        if (poderGoku == poderVegeta){
        System.err.println("\nGOGETA: ¡Muy bien! Somos mas poderosos que nunca...");
        }else if (poderGoku > poderVegeta){
            System.out.println("VEGETA: ¿Pero que demonios haces? Me has hecho mucho daño intentando esa fusión...");
        }else{
            System.out.println("VEGETA: Demonios Goku... Eres.. ¡Mucho mas debil de lo que pensaba!");
        }
        scanner.close();
            }
        }  
