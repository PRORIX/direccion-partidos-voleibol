package es.ies.puerto;
import java.util.Scanner;
/**
 * Rick ha activado su pistola de portales. Si ingresa 
 * un número divisible por 3, el portal lleva a la dimensión A. 
 * Si es divisible por 5, lleva a la dimensión B. 
 * Si es divisible por ambos, lleva a la dimensión C.
 * 
 * @author PRORIX
 * Version: 1.0.0.240924
 */

public class Ejercicio8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("RICK: ¡Pistola abre-portales-3000 lista! Ahora activaré el codigo...");
        System.out.println("¿Qué código activa Rick?");
        int codigo = scanner.nextInt();

        if (codigo%3==0){
           if (codigo%5==0){
            System.out.println("RICK: ¡Codigo " + codigo + " activado! Viajaré a la dimensión C.");
            }else{
            System.out.println("RICK: ¡Codigo " + codigo + " activado! Viajaré a la dimensión A.");
            }}
            else if (codigo%5==0){
            System.out.println("RICK: ¡Codigo " + codigo + " activado! Viajaré a la dimensión B.");
            }
        scanner.close();
        }  
}