package es.ies.puerto;
import java.util.Scanner;

/**
 * Eres un guerrero de nivel 5. Si obtienes más de 
 * 50 puntos de experiencia, subes a nivel 6. Si no, te 
 * quedas en nivel 5.
 * 
 * @author PRORIX
 * Version: 1.0.0.240924
 */


public class Ejercicio2 {
    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);

    System.out.println("¡Hola guerrero! Actualmente eres de nivel 5, para subir a nivel 6 completa la barra de experiencia, actualmente dispones de 0/50 XP");
    System.out.println("¿Cuantos puntos de experiancia has conseguido?");

    int puntosExperiencia = scanner.nextInt();
    int puntosExperienciasobrantes = puntosExperiencia - 50;
   
    if (puntosExperiencia > 50) {
        System.out.println("¡Felicidades! Con " + puntosExperiencia + " puntos de experiencia has subido a nivel 6 de guerrero! Además," +
        "¡Te han sobrado " + puntosExperienciasobrantes + " puntos de experiencia!");
    }else if (puntosExperiencia == 50) {
        System.out.println("¡Felicidades! Con " + puntosExperiencia + " puntos de experiencia has subido a nivel 6 de guerrero!");
    }else if (puntosExperiencia == 49) {   
        System.out.println("Puntos de experiencia añadidos al perfil de guerrero, ahora dispones de " + puntosExperiencia + "/50 XP.");
        System.out.println("para alcanzar el nivel 6 de guerrero has de conseguir 1 punto de experiencia más.");
    }else{
        int puntosExperienciaFaltantes =  50 - puntosExperiencia;
        System.out.println("Puntos de experiencia añadidos al perfil de guerrero, ahora dispones de " + puntosExperiencia + "/50 XP.");
        System.out.println("para alcanzar el nivel 6 de guerrero has de conseguir " + puntosExperienciaFaltantes + " puntos de experiencia más.");
    }
    scanner.close();
    }
}