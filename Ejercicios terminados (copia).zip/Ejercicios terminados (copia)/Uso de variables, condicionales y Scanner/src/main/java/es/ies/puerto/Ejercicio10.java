package es.ies.puerto;
import java.util.Scanner;
/**
 * Según tus respuestas en el sombrero seleccionador, 
 * te pueden asignar a Gryffindor, Slytherin, Ravenclaw 
 * o Hufflepuff. Elige entre valiente, astuto, sabio 
 * o leal y el programa te asignará una casa.
 * 
 * @author PRORIX
 * Version: 1.0.0.240924
 */
public class Ejercicio10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
       System.out.println("SOMBRERO SELECCIONADOR: Parece que eres un nuevo alumno ¿Eh?");
       System.out.println("SOMBRERO SELECCIONADOR: Veamos para que casa has nacido para servir...");
       System.out.println("SOMBRERO SELECCIONADOR: ¿Con qué cualidad de estas te sientes mas identificado?\n");
       System.out.println("ELIGE UNA OPCIÓN:");
       System.out.println("- VALIENTE\n- ASTUTO\n- SABIO\n- LEAL\n");
       System.out.print("Opción elegida: ");
       String opcion = scanner.nextLine();
        if ("VALIENTE".equals(opcion)){
            System.out.println("\nSOMBRERO SELECCIONADOR: Muy bien... Asi que eres alguien valiente eh... Lo seras lo suficiente como para ser de... ¡GRYFFINDOR!");
        }else if ("ASTUTO".equals(opcion)){
            System.out.println("\nSOMBRERO SELECCIONADOR: Muy bien... Asi que eres alguien astuto eh... Lo seras lo suficiente como para ser de... ¡SLYTHERIN!");
        }else if ("SABIO".equals(opcion)){
            System.out.println("\nSOMBRERO SELECCIONADOR: Muy bien... Asi que eres alguien sabio eh... Lo seras lo suficiente como para ser de... ¡RAVENCLAW!");
        }else if ("LEAL".equals(opcion)){
            System.out.println("\nSOMBRERO SELECCIONADOR: Muy bien... Asi que eres alguien leal eh... Lo seras lo suficiente como para ser de... ¡RAVENCLAW!");
        }else{
            System.out.println("\nSOMBRERO SELECCIONADOR: ¿Que has dicho? Yo no te he dado esa opción...");
        }


        scanner.close();
            }
        }  
