package es.ies.puerto;
import java.util.Scanner;
/**
 * Frodo está viajando a Mordor. Si la distancia es 
 * mayor a 1000 kilómetros, necesitará descansar. 
 * Si es menor, podrá continuar.
 * 
 * @author PRORIX
 * Version: 1.0.0.240924
 */

public class Ejercicio7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("FRODO: ¡Hola! Estoy de viaje a Mordor, pero no se cuánto me falta para llegar, ¿Me ayudas?");
        System.out.print("Distancia entre Frodo y Mordor en km: ");
        int distancia = scanner.nextInt();

        if (distancia > 1000){
            System.out.println("FRODO: ¿¡Tanto me falta!? " + distancia + " kilómetros es demasiado... mejor tomaré un descanso. ¡Gracias!");
        }else{
            System.out.println("FRODO: ¿¡Solamente!? ¡Ya en nada llego! Recorreré estos " + distancia + " kilómetros en lo que canta un gallo.");
        }
        scanner.close();
    }
}