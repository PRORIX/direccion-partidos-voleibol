package es.ies.puerto;
import java.util.EmptyStackException;
import java.util.Scanner;
/**
 * Si la energía del traje de Iron Man es mayor al 70%, 
 * puede volar. Si es mayor al 30% pero menor o igual 
 * al 70%, puede caminar. Si es menor o igual al 30%, 
 * está en modo crítico.
 * 
 * @author PRORIX
 * Version: 1.0.0.240924
 */
public class Ejercicio13 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
       System.out.println("¿Cuánto porcentaje de energía tiene Ironman en su traje ahora mismo (0%/100%)?");
       int estadoIronman = scanner.nextInt();
        
       if (estadoIronman <= 30){
        System.out.println("¡Urgencia! El traje está en modo crítico.");
       }else if (estadoIronman <= 70){
        System.out.println("Estado: Pormal (Puedes caminar)");
       }else if (estadoIronman>70){
        System.out.println("Estado: Perfecto (Puedes volar)");
       }
       scanner.close();
            }
        }  
