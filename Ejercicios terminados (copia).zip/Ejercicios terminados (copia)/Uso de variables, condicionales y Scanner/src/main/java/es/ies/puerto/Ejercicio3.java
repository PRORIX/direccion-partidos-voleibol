package es.ies.puerto;
import java.util.Scanner;

/**
 * Cada día de la semana en tu nave espacial hay una 
 * actividad diferente. Los lunes entrenas combate, los 
 * miércoles pilotaje, y los viernes reparaciones. El 
 * resto de días descansas.
 * 
 * @author PRORIX
 * Version: 1.0.0.240924
 */

public class Ejercicio3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("NAVE ESPACIAL: ¡Saludos astronauta! ¿Listo para realizar las tareas de hoy?\n");
        System.out.println("JUEGO: ¿Qué día es hoy? (Utiliza solo minúsculas)" );
        String diaSemana = scanner.nextLine();
        System.out.println("\nASTRONAUTA: ¡Hola! Hoy es " + diaSemana + ", ¿Podrías recordarme qué tareas tenia que hacer hoy?\n");

        if ("lunes".equals(diaSemana)) {
            System.out.println("NAVE ESPACIAL: ¡Claro!, sin problema...");
            System.out.println("NAVE ESPACIAL: hoy " + diaSemana + " te toca entrenar combate, ¡Adelante!");
        }else if ("miércoles".equals(diaSemana)){
            System.out.println("NAVE ESPACIAL: ¡Claro!, sin problema...");
            System.out.println("NAVE ESPACIAL: hoy " + diaSemana + " te toca pilotaje, ¡Adelante!");
        }else if ("viernes".equals(diaSemana)) {
            System.out.println("NAVE ESPACIAL: ¡Claro!, sin problema...");
            System.out.println("NAVE ESPACIAL: hoy " + diaSemana + " te toca reparaciones, ¡Adelante!");
        }else{
            System.out.println("NAVE ESPACIAL: ¡Claro!, sin problema...");
            System.out.println("NAVE ESPACIAL: ¡Pues estás de suerte!, hoy te toca día de descanso.");
        }
        System.out.println("\nASTRONAUTA: Perfecto, ¡Muchas gracias!");
        scanner.close();
    }
}