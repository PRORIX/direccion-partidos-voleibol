package es.ies.puerto;
import java.util.Scanner;
/**
 * Dos luchadores están en el combate final de Mortal 
 * Kombat. Si la salud de un luchador es 0, pierde. 
 * Si ambos tienen salud, se evalúa quién tiene 
 * más ataque. Si ambos tienen el mismo ataque, 
 * el combate es un empate.
 * 
 * @author PRORIX
 * Version: 1.0.0.240924
 */

public class Ejercicio20 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
       System.out.println("¡Combate final de Mortal Kombat!");
       System.out.print("Salud del luchador 1: ");
       int salud1 = scanner.nextInt();
       if (salud1 <= 0){
            System.out.println("El luchador 1 está muerto.");
            System.out.println("Luchador 2 gana el kombate");
       }else{
        System.out.print("Salud del luchador 2: ");
        int salud2 = scanner.nextInt();
            if (salud2<=0){
                System.out.println("El luchador 2 está muerto.");
                System.out.println("Luchador 1 gana el kombate.");
            }else{
                System.out.print("Ataque del luchador 1:");
                int ataque1 = scanner.nextInt();
                System.out.print("Ataque del luchador 2:");
                int ataque2 = scanner.nextInt();
                if (ataque1 < ataque2){
                    System.out.println("Luchador 1 tiene menos fuerza que el 2, por lo que gana el kombate el luchador 2.");
                }else if (ataque1 > ataque2){
                    System.out.println("Luchador 2 tiene menos fuerza que el 1, por lo que gana el kombate el luchador 1.");
                }else{
                    System.out.println("Ambos luchadores tienen igual fuerza, estamos ante un empate.");
                }
            }
       }
       
        scanner.close();
            }
        }  
