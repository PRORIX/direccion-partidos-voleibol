package es.ies.puerto;
import java.util.Scanner;
/**
 * Si tienes más de 18 años, eres aceptado en la Resistencia. 
 * Si tienes menos de 18 pero eres hábil con armas, 
 * también eres aceptado. Si no, debes esperar.
 * el ataque.
 * 
 * @author PRORIX
 * Version: 1.0.0.240924
 */

public class Ejercicio18 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
       System.out.println("GUARDIA: ¡Bienvenido a la sede de admisión de acceso a la resistencia!");
       System.out.println("GUARDIA: Parece que quieres ser aceptado en nuestro grupo.");
       System.out.print("GUARDIA: Primeramente, ¿Cuántos años tienes?");
       System.out.print("TÚ: Tengo ");
       int edad = scanner.nextInt();
        if (edad >= 18) {
            System.out.println("\nGUARDIA: Bien, eres mayor de edad, eres aceptado en la resistencia.");   
        }else{
            System.out.println("\nGUARDIA: Parece que aún eres menor de edad, ¿Alguien habil con las armas? (Sí,No)");
            String habilidad = scanner.next();
                switch (habilidad){
                    case "Sí":
                        System.out.println("\nGUARDIA: Muy bien, en ese caso, podrás ser aceptado igualmente en la Resistencia.");
                        break;
                    case "No":
                        System.out.println("\n GUARDIA: Lo siento mucho, debes esperar a ser mayor de edad.");
                    break;
                    default:
                    System.out.println("Respuesta incorrecta.");
            }
        }
        scanner.close();
            }
        }  
