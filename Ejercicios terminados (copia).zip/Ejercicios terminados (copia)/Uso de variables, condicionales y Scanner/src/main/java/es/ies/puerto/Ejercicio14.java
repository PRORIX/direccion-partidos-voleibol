package es.ies.puerto;
import java.util.Scanner;
/**
 * Si tu pokémon es de tipo Agua y el rival es de tipo 
 * Fuego, ganas. Si es Planta, pierdes. Si el rival es 
 * Agua, empatas.
 * 
 * @author PRORIX
 * Version: 1.0.0.240924
 */
public class Ejercicio14 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
       System.out.println("¡Bienvenido a las batallas de Pokemon!");
       System.out.println("Aquí podrás hacer pelear tus bestias y ver que tipo es mas fuerte.");
       System.out.println("Existen 3 tipos: agua, fuego y planta.");
       System.out.println("\n ¿Qué tipo de pokemon tienes? (Solo minúsculas.)");     
       String tuPokemon = scanner.nextLine();
       System.out.println("\n ¿Qué tipo de pokemon tiene tu enemigo? (Solo minúsculas.)");     
       String otroPokemon = scanner.nextLine();
        if ("agua".equals(tuPokemon)){
            switch(otroPokemon){
            case "fuego":
            System.out.println("¡Has ganado!");
            break;
            case "planta":
            System.out.println("¡Has perdido!");
            break;
            case "agua":
            System.out.println("¡Habeis empatado!");
            break;
            default:
            System.out.println("Ese tipo de pokemon, para el enemigo, no existe.");
            break;
            }
         }else if ("fuego".equals(tuPokemon)){
            switch(otroPokemon){
            case "fuego":
            System.out.println("¡Habeis empatado!");
            break;
            case "planta":
            System.out.println("¡Has ganado!");
            break;
            case "agua":
            System.out.println("¡Has perdido!");
            break;
            default:
            System.out.println("Ese tipo de pokemon, para el enemigo, no existe.");
            break;
            }
        }else if ("planta".equals(tuPokemon)){
            switch(otroPokemon){
            case "fuego":
            System.out.println("¡Has perdido!");
            break;
            case "planta":
            System.out.println("¡Haeis empatado!");
            break;
            case "agua":
            System.out.println("¡Has ganado!");
            break;
            default:
            System.out.println("Ese tipo de pokemon, para el enemigo, no existe.");
            break;
            }
        }else{
            System.out.println("Ese tipo de pokemon, el tuyo, no existe.");
        }
        scanner.close();
    }
}