package es.ies.puerto;
import java.security.Policy;
import java.util.Scanner;

/**
 * Estás cazando pokémon. Si el pokémon es de tipo 
 * Agua, Fuego o Planta, puedes usar la pokébola. 
 * Si es de cualquier otro tipo, no.
 * 
 * @author PRORIX
 * Version: 1.0.0.240924
 */

public class Ejercicio6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("¡Parece que has encontrado un pokemon! ¿De qué tipo es?");
        System.out.print("Tipo ");
        String tipoPokemon = scanner.nextLine();

        if ("agua".equals(tipoPokemon)){
            System.out.println("¡Genial! Si es de tipo " + tipoPokemon + " puedes usar la pokébola.");
        }else if ("fuego".equals(tipoPokemon)){
            System.out.println("¡Genial! Si es de tipo " + tipoPokemon + " puedes usar la pokébola.");
        }else if ("planta".equals(tipoPokemon)){
            System.out.println("¡Genial! Si es de tipo " + tipoPokemon + " puedes usar la pokébola.");
        }else{
            System.out.println("Vaya, para atrapar un pokemon de tipo " + tipoPokemon + " no puedes utilizar la pokébola.");
        }
        scanner.close();
    }
}