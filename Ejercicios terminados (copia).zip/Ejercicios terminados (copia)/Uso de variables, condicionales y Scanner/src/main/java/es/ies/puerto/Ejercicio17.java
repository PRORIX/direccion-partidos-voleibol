package es.ies.puerto;
import java.util.Scanner;
/**
 * En una batalla de rol, si el atacante tiene más fuerza 
 * que el defensor, le inflige un daño igual a la 
 * diferencia de fuerza. Si no, el defensor bloquea 
 * el ataque.
 * 
 * @author PRORIX
 * Version: 1.0.0.240924
 */

public class Ejercicio17 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
       System.out.println("¡Batalla de roles!");
       System.out.println("El atacante está a punto de lanzar un ataque al defensor");
       System.out.print("\nFuerza del atacante: ");
       int fuerzaAtacante = scanner.nextInt();
       System.out.print("\nFuerza del defensor: ");
       int fuerzaDefensor = scanner.nextInt();
        if (fuerzaAtacante > fuerzaDefensor) {
            int diferencia = (fuerzaAtacante - fuerzaDefensor);
            System.out.println("\n¡El atacante lanza su ataque!");
            System.out.println("El atacante ha hecho un daño de " + diferencia + " puntos de daño al defensor.");     
        }else{
            System.out.println("\nEl atacante no tiene más fuerza que el defensor, por lo que éste bloquea su ataque.");
        }
        scanner.close();
            }
        }  
