package es.ies.puerto;
import java.util.Scanner;

/**
 * Goku está en una batalla. Si su nivel de poder es 
 * mayor de 9000, está en "Modo Super Saiyan". 
 * Si no, está en "Modo normal".
 * 
 * @author PRORIX
 * Version: 1.0.0.240924
 */

public class Ejercicio5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("VEGETA: Goku, hoy, moriras...");
        System.out.println("GOKU: (rie), comprobémoslo.");
        System.out.println("\nJUEGO: ¿Cuánto poder tiene goku ahora mismo?");
        int puntosDePoder = scanner.nextInt();
        if (puntosDePoder>=9000){
            System.out.println("\nGOKU: (Activa el Modo Super Saiyan) repíteme lo mismo ahora...");
            System.out.println("VEGETA: ¿De donde noto tanto KI?");
        }else{
            System.out.println("\nVEGETA: (lo derriba) Que lamentable...");
        }
        scanner.close();
    }
}