package es.ies.puerto;
import java.util.EmptyStackException;
import java.util.Scanner;
/**
 * Si tienes un arma de fuego y munición, puedes luchar 
 * contra los zombies. Si tienes un arma cuerpo a cuerpo, 
 * puedes defenderte. Si no tienes armas, debes huir.
 * 
 * @author PRORIX
 * Version: 1.0.0.240924
 */
public class Ejercicio16 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
       System.out.println("¡Tienes una enorme horda de zombis detras tuya! Debes utilizar rápidamente algún arma, si tienes.");
       System.out.println("¿Dispones de algún arma? (Sí, No)");
       String tieneArma = scanner.nextLine();
       if ("Sí".equals(tieneArma)){
                System.out.println("\n¿Qué arma tienes?(A,B)");
                System.out.println("\nA. Cuchillo");
                System.out.println("B. Rifle de asalto");
                String arma = scanner.nextLine();
                    if ("A".equals(arma)){
                            System.out.println("\nCon un cuchillo eres capaz de defenderte dificilmente de los zombis, pero logras resistir.");
                            System.out.println("¡Buen trabajo!");
                    }else if ("B".equals(arma)){
                            System.out.println("\n ¿Dispones de munición? (Sí, No)");
                            String municion = scanner.nextLine();
                                switch(municion){
                                    case "Sí":
                                        System.out.println("¡Exelente!");
                                        System.out.println("Con el arma de fuego logras acabar con todos los zombis sin problema.");
                                        break;                               
                                    case "No":
                                        System.out.println("Vaya, sin munición en el rifle logras acabar con un par de zombis utilizando el rifle como arma de cuerpo a cuerpo, pero no tardas en caer.");
                                        System.out.println("¡Moriste!");
                                        break;
                                    default:
                                        System.out.println("Respuesta incorrecta.");
                                        break;
                                    }
                    }else{
                            System.out.println("Respuesta incorrecta.");
                            }
                        
    }else if ("No".equals(tieneArma)){
            System.out.println("¡No tienes arma, toca huir!");
            System.out.println("Consigues escapar de los zomibis, pero éstos siguen vivos.");
            System.out.println("¡Bien hecho!");

    }else{
            System.out.println("Respuesta incorrecta.");
            }
    scanner.close();
    }
}

