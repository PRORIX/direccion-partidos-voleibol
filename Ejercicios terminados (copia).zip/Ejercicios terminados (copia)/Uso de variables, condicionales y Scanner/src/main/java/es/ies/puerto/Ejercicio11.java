package es.ies.puerto;
import java.util.Scanner;
/**
 * Si la velocidad de la Millennium Falcon es mayor de 
 * 1000, se activan los motores hiperespaciales. Si 
 * es mayor de 500 pero menor o igual a 1000, la 
 * nave está a máxima velocidad. Si es menor o 
 * igual a 500, la nave está en velocidad normal.
 * 
 * @author PRORIX
 * Version: 1.0.0.240924
 */

public class Ejercicio11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
       System.out.println("Bienvenido a la Millennium Flacon");
       System.out.println("¿A que velocidad desea viajar?");
       System.out.print("\nVELOCIDAD: ");
       int velocidad = scanner.nextInt();
        if (velocidad <=500) {
            System.out.println("Activando el modo normal.");      
        }else if(velocidad <=1000){
            System.out.println("Activando máxima velocidad.");
        }else{
            System.out.println("Preparando el sistema de motores hiperespaciales, activando modo de seguridad de la tripulación.");
        }
        scanner.close();
            }
        }  
