package es.ies.puerto;
import java.util.EmptyStackException;
import java.util.Scanner;
/**
 * Link encuentra tres objetos en una mazmorra: una llave, 
 * una bomba y un arco. Si tiene la llave, puede abrir la 
 * puerta. Si tiene la bomba, puede destruir la puerta. 
 * Si tiene el arco, puede atacar a los enemigos desde 
 * lejos.
 * 
 * @author PRORIX
 * Version: 1.0.0.240924
 */
public class Ejercicio15 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
       System.out.println("¡Puerta bloqueada! No la puedes abrir\nParece haber un cofre, lo abres:\n");
       System.out.println("A. Una llave");
       System.out.println("B. Una bomba");
       System.out.println("C. Un arco");
       System.out.println("¿Qué objeto escojes? (A,B,C)");
       String objeto = scanner.nextLine();
       switch(objeto){
        case "A":
            System.out.println("Has elegido la llave.");
            System.out.println("Abres la puerta.");
        break;
        case "B":
            System.out.println("Has elegido la bomba.");
            System.out.println("Destruyes la puerta.");
        break;
        case "C":
            System.out.println("Has elejido el arco.");
            System.out.println("No puedes abrir la puerta, pero luchas contra tus enemigos a la distancia.");
        break;
        default:
            System.out.println("No has elegido una opción válida, mueres.");
       }
       scanner.close();
       }
}

