package es.ies.puerto;
import java.util.Scanner;
/**
 * Si tienes más de 500 minerales y más de 300 gas, 
 * puedes construir un coloso. Si no 
 * tienes suficientes recursos, construyes un marine.
 * 
 * @author PRORIX
 * Version: 1.0.0.240924
 */

public class Ejercicio19 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
       System.out.println("¡Bienvenido a SpaceCraft!");
       System.out.print("Cantidad de minerales: ");
       int minerales = scanner.nextInt();
       if (minerales > 500){
            System.out.print("Cantidad de coloso: ");
            int gas = scanner.nextInt();
            if (gas > 300){
                System.out.println("\n¡Genial! Tienes materiales suficientes para construir un coloso.");
            }else{
                System.out.println("\nVaya, no tienes suficiente gas, has de construir un marine.");
            }
       }else{
        System.out.println("\nVaya, no tienes suficientes minerales, has de constuir un marine.");
       }
       
        scanner.close();
            }
        }  
