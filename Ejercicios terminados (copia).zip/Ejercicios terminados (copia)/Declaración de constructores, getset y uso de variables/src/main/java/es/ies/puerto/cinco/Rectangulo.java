package es.ies.puerto.cinco;

public class Rectangulo {
    private double base;
    private double altura;

    // Constructor vacío

    public Rectangulo(){}

    /**
     * Constructor con parámetros
     * @param base del rectangulo
     * @param altura del rectangulo
     */

    public Rectangulo(double base, double altura){
        this.base = base;
        this.altura = altura;
    }

    // Getters y setters


    public double getBase() {
        return this.base;
    }

    public void setBase(double base) {
        this.base = base;
    }

    public double getAltura() {
        return this.altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    // Método para calcular el área del rectángulo

    public double calcularArea(){
        return base * altura;
    }

    // Método para calcular el perímetro del rectángulo

    public double calcularPerimetro(){
        return 2*(base + altura);
    }

    // Método para mostrar la información del rectángulo


    @Override
    public String toString() {
        return "{" +
            " base='" + getBase() + "'" +
            ", altura='" + getAltura() + "'" +
            "}";
    }
    
}
