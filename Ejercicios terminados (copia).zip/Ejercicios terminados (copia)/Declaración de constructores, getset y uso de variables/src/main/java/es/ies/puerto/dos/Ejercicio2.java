package es.ies.puerto.dos;

public class Ejercicio2 {
    
    static private Persona persona;
    public static void main(String[] args) {
        persona = new Persona(30, "Juan");
        persona.mostrarInformacion();
    }
}
