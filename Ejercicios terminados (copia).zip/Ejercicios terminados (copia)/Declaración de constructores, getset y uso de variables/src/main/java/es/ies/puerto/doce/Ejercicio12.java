package es.ies.puerto.doce;

public class Ejercicio12 {
    public static void main(String[] args) {
        Libro libro = new Libro("El Quijote", "Cervantes", 500);
        System.out.println(libro);
    }
    
}
