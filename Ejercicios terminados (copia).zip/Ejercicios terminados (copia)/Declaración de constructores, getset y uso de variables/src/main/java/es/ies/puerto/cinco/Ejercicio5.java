package es.ies.puerto.cinco;
/**
 * Crea una clase llamada Rectangulo con los 
 * atributos base y altura. Implementa un 
 * método que calcule el área del rectángulo. 
 * Usa getters y setters para los atributos.
 * @author prorix
 * @version 1.0.0
 */
public class Ejercicio5 {
    public static void main(String[] args) {
        Rectangulo rectangulo = new Rectangulo(5, 10);
        System.out.println(rectangulo);
        System.out.println(rectangulo.calcularArea());
        System.out.println(rectangulo.calcularPerimetro());
    }
}
