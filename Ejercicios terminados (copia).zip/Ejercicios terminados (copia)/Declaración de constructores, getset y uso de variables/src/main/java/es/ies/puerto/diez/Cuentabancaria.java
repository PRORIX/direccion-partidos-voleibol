package es.ies.puerto.diez;

public class Cuentabancaria {
    private String titular;
    private float saldo;

    // Constructor vacío

    public Cuentabancaria(){}

    /**
     * Constructor con parámetros
     * @param titular de la cuenta
     * @param saldo de la cuenta
     */

    public Cuentabancaria(String titular, float saldo){
        this.titular = titular;
        this.saldo = saldo;
    }

    // Getters y setters


    public String getTitular() {
        return this.titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public float getSaldo() {
        return this.saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    // Método para mostrar la información de la cuenta


    @Override
    public String toString() {
        return "{" +
            " titular='" + getTitular() + "'" +
            ", saldo='" + getSaldo() + "'" +
            "}";
    }

    // Método para transferir dinero entre cuentas

    
    public boolean transferir(Cuentabancaria cuentaEnviadora, Cuentabancaria cuentaReceptora, float cantidad){
        if (cuentaEnviadora.saldo < cantidad){
            System.out.println("Saldo insuficiente");
            return false;
        }
        cuentaEnviadora.saldo = cuentaEnviadora.saldo - cantidad;
        cuentaReceptora.saldo = cuentaReceptora.saldo + cantidad;
        return true;
    }


    
}
