package es.ies.puerto.tres;

public class Ejercicio3 {
    private static Coche coche;
    public static void main(String[] args) {
        coche = new Coche("Toyota", "Corolla", 2022);
        coche.mostrarDatosCoche();
    }
}