package es.ies.puerto.ocho;

public class Ejercicio8 {
    public static void main(String[] args) {
        Empleado empleado1 = new Empleado("Ana", "Gerente", 5000);
        
    }
    
}
