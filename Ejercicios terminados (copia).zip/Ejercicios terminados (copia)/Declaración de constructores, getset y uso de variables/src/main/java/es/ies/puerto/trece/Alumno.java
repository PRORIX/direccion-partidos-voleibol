package es.ies.puerto.trece;

public class Alumno {
    private String nombre;
    private int nota;

    // Constructor vacío

    public Alumno() {
    }

    /**
     * Constructor con parámetros
     * 
     * @param nombre del alumno
     * @param nota   del alumno
     */

    public Alumno(String nombre, int nota) {
        this.nombre = nombre;
        this.nota = nota;
    }

    // Getters y setters

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNota() {
        return this.nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }

    // Método para mostrar la información del alumno


    @Override
    public String toString() {
        return "{" +
            " nombre='" + getNombre() + "'" +
            ", nota='" + getNota() + "'" +
            "}";
    }

    // Método para saber si el alumno ha aprobado

    public void aprueba (Alumno alumno){
        if (nota >=5){
            System.out.println("Aprueba");
        }else{
            System.out.println("No aprueba");
        }
    }


}
