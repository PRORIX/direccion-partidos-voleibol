package es.ies.puerto.siete;

public class Ejercicio7 {
    public static void main(String[] args) {
        Banco banco = new Banco(1000);
        banco.aniadir(500);
        banco.quitar(200);
        System.out.println(banco);
    }
    
}
