package es.ies.puerto.diez;

public class Ejercicio10 {
    public static void main(String[] args) {
        Cuentabancaria cuenta1 = new Cuentabancaria("Pedro", 1500);
        Cuentabancaria cuenta2 = new Cuentabancaria("Laura", 1000);
        Cuentabancaria cuenta3 = new Cuentabancaria("Luis", 500);
        Cuentabancaria cuenta4 = new Cuentabancaria("Sofía", 3000);
        cuenta1.transferir(cuenta1, cuenta2, 500);
        System.out.println(cuenta1);
        System.out.println(cuenta2);
        cuenta3.transferir(cuenta3, cuenta4, 1000);
        System.out.println(cuenta3);
        System.out.println(cuenta4);
        
    }
    
}
