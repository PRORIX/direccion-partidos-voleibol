package es.ies.puerto.trece;

public class Ejercicio13 {
    public static void main(String[] args) {
        Alumno alumno1 = new Alumno("Lucia", 7);
        Alumno alumno2 = new Alumno("Pedro", 2);
        alumno1.aprueba(alumno1);
        alumno2.aprueba(alumno2);
    }
    
}
