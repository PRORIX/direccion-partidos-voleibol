package es.ies.puerto.doce;

public class Libro {
    private String titulo;
    private String autor;
    private int paginas;

    // Constructor vacío

    public Libro(){}

    /**
     * Constructor con parámetros
     * @param titulo del libro
     * @param autor del libro
     * @param paginas del libro
     */

    public Libro(String titulo, String autor, int paginas){
        this.titulo = titulo;
        this.autor = autor;
        this.paginas = paginas;
    }

    // Getters y setters


    public String getTitulo() {
        return this.titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return this.autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getPaginas() {
        return this.paginas;
    }

    public void setPaginas(int paginas) {
        this.paginas = paginas;
    }

    // Método para mostrar la información


    @Override
    public String toString() {
        return "{" +
            " titulo='" + getTitulo() + "'" +
            ", autor='" + getAutor() + "'" +
            ", paginas='" + getPaginas() + "'" +
            "}";
    }




}
