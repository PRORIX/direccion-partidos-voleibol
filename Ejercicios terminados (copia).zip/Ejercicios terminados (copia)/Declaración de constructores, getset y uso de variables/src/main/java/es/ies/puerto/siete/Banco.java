package es.ies.puerto.siete;

public class Banco {
    private float saldo;

    // Constructor vacío

    public Banco(){}

    /**
     * Constructor con parámetros
     * @param saldo del banco
     */

    public Banco(float saldo){
        this.saldo = saldo;
    }

    // Getters y setters


    public float getSaldo() {
        return this.saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    // Método para mostrar la información


    @Override
    public String toString() {
        return "{" +
            " saldo='" + getSaldo() + "'" +
            "}";
    }

    // Método para añadir saldo

    public boolean aniadir(float dineroAniadir){
        saldo = saldo + dineroAniadir;
        return true;
    }

    public boolean quitar(float dineroQuitar){
        saldo = saldo - dineroQuitar;
        return true;
    }


    
}
