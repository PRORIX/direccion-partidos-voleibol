package es.ies.puerto.ocho;

public class Empleado {
    private String nombre;
    private String puesto;
    private float salario;

    // Constructor vacío

    public Empleado(){}

    /**
     * Constructor con parámetros
     * @param nombre del empleado
     * @param puesto del empleado
     * @param salario del empleado
     */

    public Empleado(String nombre, String puesto, float salario){
        this.nombre = nombre;
        this.puesto = puesto;
        this.salario = salario;
    }

    // Getters y setters


    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPuesto() {
        return this.puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public float getSalario() {
        return this.salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    // Método para mostrar la información


    @Override
    public String toString() {
        return "{" +
            " nombre='" + getNombre() + "'" +
            ", puesto='" + getPuesto() + "'" +
            ", salario='" + getSalario() + "'" +
            "}";
    }


    
}
