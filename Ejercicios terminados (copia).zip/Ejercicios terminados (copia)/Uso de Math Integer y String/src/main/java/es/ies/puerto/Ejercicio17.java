package es.ies.puerto;
/**
 * Simula el daño crítico de un ataque multiplicando el 
 * daño base por un número aleatorio entre 1.5 y 2.0 
 * usando Math.random().
 * @author: prorix
 * @version: 1.0.0.081024
 */
public class Ejercicio17 {
public static void main(String[] args) {
    int danioBase = 200;
    double potenciador = 1.5 + Math.random();
    double danioTotal = danioBase * potenciador;
    System.out.println(danioTotal);
            }
}


//PREGUNTAR