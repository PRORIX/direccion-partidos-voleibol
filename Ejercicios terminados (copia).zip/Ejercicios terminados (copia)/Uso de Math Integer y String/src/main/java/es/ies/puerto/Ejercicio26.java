package es.ies.puerto;
/**
 * Compara el poder de pelea de Goku (9000) con el de 
 * Vegeta (8500) usando el método Integer.compare().
 * @author: prorix
 * @version: 1.0.0.081024
 */
public class Ejercicio26 {
public static void main(String[] args) {
    int poderGoku = 9000;
    int poderVegeta = 8500;
    Integer comparacion = Integer.compare(poderGoku,poderVegeta);
    System.out.println(comparacion);
            }
}