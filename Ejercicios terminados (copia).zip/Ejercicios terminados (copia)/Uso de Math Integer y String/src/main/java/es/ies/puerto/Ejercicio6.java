package es.ies.puerto;
/**
 * Crea un programa que dada la frase "Viva la Resistencia", 
 * cuente cuántas veces aparece la letra "a".
 * @author: prorix
 * @version: 1.0.0.081024
 */
public class Ejercicio6 {
    public static void main(String[] args) {
        String frase = "Viva la Resistencia";
        int contador = 0;
        frase = frase.trim();
        char [] arrayFrase = frase.toCharArray();
        for(int i=0 ; i<arrayFrase.length ; i++){
            if (arrayFrase[i] == 'a'){
            contador++;
        }
    }
        System.out.println("Veces que aparece: " + contador);
}
}