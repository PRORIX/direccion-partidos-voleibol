package es.ies.puerto;
import java.util.Scanner;
/**
 * Dado el nombre "Goku", crea un programa que añada "SSJ" 
 * al final de su nombre dependiendo del nivel 
 * (e.g. "Goku SSJ1", "Goku SSJ2").
 * @author: prorix
 * @version: 1.0.0.081024
 */
public class Ejercicio5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String nombre = "Goku";
        String fase = "SSJ";
        System.out.print("Nivel de goku: ");
        int nivel = scanner.nextInt();
        String frase = nombre + " " + fase + nivel;
        System.out.println(frase);
        scanner.close();
    }
}