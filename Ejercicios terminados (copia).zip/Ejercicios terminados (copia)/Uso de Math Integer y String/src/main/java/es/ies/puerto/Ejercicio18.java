package es.ies.puerto;
/**
 * Dadas las masas de dos planetas y la distancia entre 
 * ellos, calcula la fuerza gravitacional entre ellos 
 * usando la fórmula de la Ley de Gravitación Universal 
 * y Math.pow().
 * @author: prorix
 * @version: 1.0.0.081024
 */
public class Ejercicio18 {
public static void main(String[] args) {
    double masa1 = 6*10e24;
    double masa2 = 7*10e22;
    double distancia = 10e8;
    double g = 6.67e-11;
    double fuerzaGravitacional = (g * masa1 * masa2) / Math.pow(distancia , 2);
    System.out.println("G ≈ " + fuerzaGravitacional);
            }
}