package es.ies.puerto;
/**
 * Dado el código Sith: "La paz es una mentira, solo hay 
 * pasión", crea un programa que cuente cuántas veces 
 * aparece la palabra "es".
 * @author: prorix
 * @version: 1.0.0.081024
 */
public class Ejercicio23 {
public static void main(String[] args) {
    String frase = "La paz es una mentira, solo hay pasión";
    String palabra = "es";
    int contador = 0;
        String [] arrayFrase = frase.split(" ");
        for(String p : arrayFrase){
            if (p.equals(palabra)){
            contador++;
        }
    }
    System.out.println(contador);
    }
}