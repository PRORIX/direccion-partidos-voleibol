package es.ies.puerto;
/**
 * Dada la frase "Que la fuerza te acompañe", 
 * crea un programa que convierta todas las letras 
 * en mayúsculas.
 * @author: prorix
 * @version: 1.0.0.081024
 */
public class Ejercicio20 {
public static void main(String[] args) {
    String frase = "Que la fuerza te acompañe";
    String fraseMayuscula = frase.toUpperCase();
    System.out.println(fraseMayuscula);
    }
}