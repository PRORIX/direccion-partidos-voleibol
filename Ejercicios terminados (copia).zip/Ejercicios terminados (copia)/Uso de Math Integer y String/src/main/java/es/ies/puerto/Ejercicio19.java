package es.ies.puerto;
/**
 * Crea un programa que simule el lanzamiento de un dado 
 * de 20 caras usando Math.random() y que imprima 
 * l resultado del lanzamiento.
 * @author: prorix
 * @version: 1.0.0.081024
 */
public class Ejercicio19 {
public static void main(String[] args) {
    int resultadoDado = (int) (19 * Math.random()+1);
    System.out.println(resultadoDado);
    }
}