package es.ies.puerto;
/**
 * Dado que el rayo de Thor tiene una velocidad 
 * v = 3 × 10^8 m/s y la distancia a la Tierra es 
 * d = 1.5 × 10^11 metros, calcula el tiempo que tarda 
 * en llegar usando la fórmula t = d / v.
 * @author: prorix
 * @version: 1.0.0.081024
 */
public class Ejercicio28 {
public static void main(String[] args) {

    double rayoThor = 3*10e8;
    double distancia = 1.5*10e11;
    double tiempo = distancia / rayoThor;
    System.out.println(tiempo);
            }
}