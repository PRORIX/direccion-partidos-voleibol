package es.ies.puerto;
/**
 * En un videojuego de rol, un ataque causa un daño de 
 * 1567 puntos. Usa Integer.toString() para convertir 
 * el daño en cadena y mostrarlo.
 * @author: prorix
 * @version: 1.0.0.081024
 */
public class Ejercicio11 {
public static void main(String[] args) {
    Integer danio = 1567;
    Integer.toString(danio);
    System.out.println(danio);
    }
}