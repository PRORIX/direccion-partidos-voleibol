package es.ies.puerto;
/**
 * Crea un programa que convierta un poder de 
 * pelea (entero) en un string y viceversa 
 * usando los métodos Integer.parseInt() 
 * y Integer.toString().
 * @author: prorix
 * @version: 1.0.0.081024
 */
public class Ejercicio13 {
    public static void main(String[] args) {
        String poderComoCadena = "5000";
        int poderComoEntero = 4000;
        int poderDesdeCadena = Integer.parseInt(poderComoCadena);
        System.out.println("Entero: " + poderDesdeCadena);
        String poderDesdeEntero = Integer.toString(poderComoEntero);
        System.out.println("Cadena: " + poderDesdeEntero);
    }
}
