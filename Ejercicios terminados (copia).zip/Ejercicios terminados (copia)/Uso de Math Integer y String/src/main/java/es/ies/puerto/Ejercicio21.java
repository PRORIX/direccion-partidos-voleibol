package es.ies.puerto;
/**
 * Dado el nombre "Thor Odinson", crea un programa que 
 * imprima solo el apellido usando substring() y 
 * indexOf().
 * @author: prorix
 * @version: 1.0.0.081024
 */
public class Ejercicio21 {
public static void main(String[] args) {
    String nombre = "Thor Odinson";
    String apellido = nombre.substring(5);
    System.out.println(apellido);
            }
}