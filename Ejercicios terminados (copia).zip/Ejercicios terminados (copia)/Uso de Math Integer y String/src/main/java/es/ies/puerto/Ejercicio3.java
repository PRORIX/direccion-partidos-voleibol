package es.ies.puerto;
/**
 * Dado el nombre de un Pokémon (como "Pikachu"), crea un 
 * programa que convierta el nombre en mayúsculas, 
 * minúsculas, y que también imprima la longitud del 
 * nombre.
 * @author: prorix
 * @version: 1.0.0.081024
 */
public class Ejercicio3 {
    public static void main(String[] args) {
        String palabra = "Pikachu";
        String palabraMinuscula = palabra.toLowerCase();
        String palabraMayuscula = palabra.toUpperCase();
        int tamanioPalabra = palabra.length();
        System.out.println(palabraMinuscula);
        System.out.println(palabraMayuscula);
        System.out.println(tamanioPalabra);
    }
}