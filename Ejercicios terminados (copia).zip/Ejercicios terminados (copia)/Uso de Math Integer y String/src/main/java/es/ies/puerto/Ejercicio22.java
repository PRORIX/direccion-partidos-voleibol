package es.ies.puerto;
/**
 * Dado un hechizo como "Expecto Patronum", crea un 
 * programa que verifique si comienza con 
 * "Expecto" y termina con "Patronum".
 * @author: prorix
 * @version: 1.0.0.081024
 */
public class Ejercicio22 {
public static void main(String[] args) {
    String hechizo = "Expectro Patronum";
    boolean existe = hechizo.startsWith("Expectro");
        if (existe=true){
            boolean existe2= hechizo.endsWith("Patronum");
            System.out.println(existe2);
        }else{
            System.out.println(existe);
        }
            }
}