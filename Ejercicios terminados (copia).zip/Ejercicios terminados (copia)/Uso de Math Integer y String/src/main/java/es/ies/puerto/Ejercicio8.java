package es.ies.puerto;
/**
 * Escribe un programa que reciba una entrada del usuario 
 * y convierta la primera letra de cada palabra 
 * en mayúscula (como si fuera el diario del Capitán Kirk).
 * @author: prorix
 * @version: 1.0.0.081024
 */
public class Ejercicio8 {
    public static void main(String[] args) {
        String frase = "en un universo alterno";
        String[] palabras = frase.split(" ");
        for(int i=0 ; i < palabras.length ; i++){
        String palabra = palabras[i];
        String primeraLetra = palabra.substring(0,1);
        String primeraLetraMayuscula = primeraLetra.toUpperCase();
        palabra = palabra.replaceFirst(primeraLetra, " " + primeraLetraMayuscula);
        System.out.print(palabra);
        }
    }
}