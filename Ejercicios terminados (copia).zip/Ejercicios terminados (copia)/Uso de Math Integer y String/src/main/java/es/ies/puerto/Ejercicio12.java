package es.ies.puerto;
/**
 * Dada la transformación Saiyan en nivel 9000, convierte 
 * este número a hexadecimal y binario 
 * usando métodos de Integer.
 * @author: prorix
 * @version: 1.0.0.081024
 */
public class Ejercicio12 {
    public static void main(String[] args) {
        int saiyanLevel = 9000;
        String hexadecimal = Integer.toHexString(saiyanLevel);
        String binario = Integer.toBinaryString(saiyanLevel);
        System.out.println("Hexadecimal: " + hexadecimal);
        System.out.println("Binario: " + binario);
    }
}
