package es.ies.puerto;
/**
 * Dada una dirección de Gotham como "Wayne Tower, 
 * Gotham City", usa el método split() para separar 
 * la torre del nombre de la ciudad.
 * @author: prorix
 * @version: 1.0.0.081024
 */
public class Ejercicio24 {
public static void main(String[] args) {
    String ciudades = "Wayne Tower, Gotham City";
    String [] direcciones = ciudades.split(", ");
    System.out.println(direcciones);
            }
}