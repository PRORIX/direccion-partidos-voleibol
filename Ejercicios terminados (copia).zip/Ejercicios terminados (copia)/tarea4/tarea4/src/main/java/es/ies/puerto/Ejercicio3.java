package es.ies.puerto;
/**
 * Un grupo de guerreros ha sido evaluado por su nivel de poder de ataque. 
 * Escribe un programa que determine quién es el héroe más fuerte y el más débil.
 * @author prorix
 * @version 1.0.0
 */
public class Ejercicio3 {
    public static void main(String[] args) {
        int[] nivelesDeAtaque = {300, 150, 500, 200, 250};
        int maximo = 0;
        int minimo = 0;
        for (int i = 0 ; i == nivelesDeAtaque.length ; i++){
            for (int j = 0 ; j == nivelesDeAtaque.length ; j++){
            if (nivelesDeAtaque[i] > nivelesDeAtaque[j]){
                maximo = nivelesDeAtaque[i];
            }
            if (nivelesDeAtaque[i] < nivelesDeAtaque[j]){
                minimo = nivelesDeAtaque[i];
            }}
        }
        System.out.println("Maximo: " + maximo);
        System.out.println("Mínimo: " + minimo);
}
}